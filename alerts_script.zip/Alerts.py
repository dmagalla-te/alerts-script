from Connector_v7 import get_data
import csv

API_TOKEN="ffca3143-2247-4165-9989-e974c99918a7"
WINDOW="24h"
BASE_URL="https://api.thousandeyes.com/v7/"

def get_alerts():

    headers =  {
        'Accept': 'application/hal+json',
        'Authorization': f'Bearer {API_TOKEN}'
    }

    all_alerts = []

    #1. Get all the accountgroup IDs
    account_groups_url = f"{BASE_URL}account-groups"
    status_code, account_groups = get_data(headers=headers, endp_url=account_groups_url, params={})

    if status_code == 200:

        for account_group in account_groups.get('accountGroups', []):

            aid = account_group.get('aid')
            account_name = account_group.get('accountGroupName')

            print(f"Fetching alerts for Account Group: {account_name} - aid: {aid}")

            #2. For each accountgroup ID, get the active alerts from the past 24h

            active_alerts_url = f"{BASE_URL}alerts"
            params = {"window":WINDOW, "aid":aid}
            status_code, alerts = get_data(headers=headers, endp_url=active_alerts_url, params=params)

            #2.1 Compile the alerts into a list
            # Account group name, Rule Name, Alert ID
            for alert in alerts.get('alerts', []):

                rule_url = alert.get('_links','').get('rule','').get('href','')
                status_code, rule_info = get_data(headers=headers, endp_url=rule_url, params={"aid":aid})

                print(f" - Alert Name: {rule_info.get('ruleName')}, Alert ID: {alert.get('alertId')}")
                all_alerts.append([account_name, rule_info.get("ruleName"), alert.get('id')])

        
        #3. Format the alerts into a readable structure - CSV
        with open('alerts_report.csv', 'w') as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerow(["Account Group", "Rule Name", "Alert ID"])

            for alert in all_alerts:
                writer.writerow(alert)




        return all_alerts
    
    else:
        print(f"Error fetching account groups: {account_groups}")
        return []

if __name__ == "__main__":
    
    alerts = get_alerts()
    print(f"Total alerts fetched: {len(alerts)}")